import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "crypto::compare — Cryptographic Algorithm Reference",
  description:
    "Interactive reference tool for 55+ cryptographic algorithms across 12 categories. Compare security levels, key sizes, performance, and attack complexity.",
  openGraph: {
    title: "crypto::compare",
    description: "Interactive cryptographic algorithm reference — 12 categories, 55+ algorithms, international.",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <head>
        <link
          href="https://fonts.googleapis.com/css2?family=IBM+Plex+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="min-h-screen font-sans antialiased">{children}</body>
    </html>
  );
}
